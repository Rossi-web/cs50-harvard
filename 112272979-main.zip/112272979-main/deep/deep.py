r = input("What is the Answer to the Great Question of Life, the Universe, and Everything? ").lower().strip()

if r=="42" or r=="forty-two" or r=="forty two":
    print("Yes")
else:
    print("No")