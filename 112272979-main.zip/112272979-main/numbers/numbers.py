X = int(input("Qual o valor de x? "))
print("X é igual a",X)