name = input("Digite algo: ").lower()
print(name)
