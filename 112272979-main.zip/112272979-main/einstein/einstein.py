def main():
    m = int(input ("m: "))
    c = 300000000
    print("E:", m*c**2)

main()


