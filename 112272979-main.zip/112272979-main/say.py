import cowsay
import sys