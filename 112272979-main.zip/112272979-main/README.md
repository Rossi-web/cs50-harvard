Projetos criados durante o curso CS50, de Harvard, destinado a introduzir o aluno a linguagem Python. Todos eles foram criados de forma totalmente independente utilizando
os conhecimentos adquiridos durante o mesmo.
